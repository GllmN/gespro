package af.cmr.indyli.gespro.business.entity;

import java.io.Serializable;

public interface IEntity extends Serializable{
	public int getId();

	public void setId(int id);
}
