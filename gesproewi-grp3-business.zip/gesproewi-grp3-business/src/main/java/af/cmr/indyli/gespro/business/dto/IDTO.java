package af.cmr.indyli.gespro.business.dto;
import java.io.Serializable;


public interface IDTO extends Serializable{

	public int getId();
	public void setId(int id);
	
}
