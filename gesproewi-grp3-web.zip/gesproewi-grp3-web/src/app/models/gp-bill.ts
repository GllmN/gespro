export interface GpBill {
}
