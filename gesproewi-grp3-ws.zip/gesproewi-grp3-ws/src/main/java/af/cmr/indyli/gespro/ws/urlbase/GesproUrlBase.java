package af.cmr.indyli.gespro.ws.urlbase;

public class GesproUrlBase {

	public static final String url = "*";

	public static final int maxAge = 3600;
}
