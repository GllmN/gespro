package af.cmr.indyli.gespro.ws;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GesproWsApplicationTests {

	@Test
	void contextLoads() {
	}

}
