# gespro-final-ws

Pour l'exposition des services web de GESPRO